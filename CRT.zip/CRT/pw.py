#a=list(map(str,input()))
a=['a','b','c','2','3','e','#','&']
print(a)
cl,cu,cd,cs,clen,sum=0,0,0,0,0,0
if(len(a)>=8):
    clen+=1
    for i in a:
        if(i.islower() or i.isupper() or i.isdigit()):
            if (i.islower() and cl<1):
                cl=1       
            elif (i.isupper() and cu<1):
                cu=1
            elif (i.isdigit() and cd<1):
                cd=1 
        elif(cs<1):
            cs=1 
sum=clen+cl+cu+cd+cs
print(clen,cl,cu,cd,cs)
if(sum==5):
    print("success")
else:
    print(5-sum)    
            
    

             
        