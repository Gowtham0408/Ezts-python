class A():
    def __init__(self,u):
        self.x=u
        self.c=1
    def fact(self):
        for i in range(1,self.x+1):
            self.c*=i
        print(self.c)
n=int(input())                        
u=A(n)
u.fact()         
                       