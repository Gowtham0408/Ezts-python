
try:
    a=list(map(int,input().split()))
    c=0
    for i in a:
        c=c+i
    print(c)
except ValueError:
    print("invalid")
finally:
    print("end")            