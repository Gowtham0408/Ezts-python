# a=list(map(int,input().split()))
# b=int(input())
# sum=0
# count=0
# a.sort()
# for i in range(len(a)-1):
#     if(a[i]<b):
#         count+=1
#     else:
#         i=+1
# print(count) 

class A:
    def __init__(self):
        self.x=20
    def fun(self):
        print("hi")
class B(A):
    def __init__(self):
        super().__init__()
        self.y=50 
    def fun(self):
        print("hello",self.x,self.y)
b=B()                      
b.fun()