
class A():
    def __init__(self,u):
        self.x=u
    def even(self):
        if(self.x%2==0):
            return True
        else:
            return False
n=int(input())        
u=A(n)
if(u.even()):
    print("even")
else:
    print("odd")    
        
                