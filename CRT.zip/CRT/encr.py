a=input()
b=int(input())
s=""
# for i in a:
#     j=ord(i)+b  
#     if(j>122):
#         j=96+(j-122)
#     s=s+str(chr(j))
# print(s)
for i in a:
    j=ord(i)-b
    if(j<97):
        j=123-(97-j)
    s=s+str(chr(j))
print(s)    