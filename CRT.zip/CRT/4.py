import math
a=math.sqrt(3)
print(a)