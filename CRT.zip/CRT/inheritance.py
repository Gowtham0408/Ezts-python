#one class do not have before class constructor until it is super()
class A:
    def __init__(self):
        self.x=50
    def fun(self):
        print("hi")
class B(A):
    def __init__(self):
        super().__init__()
        self.y=100
    def fun(self):    
        print("hello",self.x,self.y)      
b=B()
b.fun()    

#multiple Inheritance
class A:
    def fun(self):
        print("hi")

class B:
    def fun(self):
        print("hello")
    
class C(A,B):
    def fun1(self):
        print("bye")  
        
c=C()
c.fun()  

#multilevel Inheritance

class A:
    def fun(self):
        print("Grandpa")
class B(A):
    def fun1(self):
        print("Father")
class C(B):
    def fun2(self):
        print("Son")
c=C()
c.fun()      

#hierarchical Inheritance

class A:
    def fun(self):
        print("Mother") 
class B(A):
    def fun1(self):
        print("Son") 
class C(A):
    def fun2(self):
        print("Daughter")
b=B()                                                    
c=C()
b.fun1()
c.fun2()